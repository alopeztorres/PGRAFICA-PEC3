// C library

void LibFunction()
{
}